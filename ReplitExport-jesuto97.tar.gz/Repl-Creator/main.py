# ¡Tu entorno Python está listo!
# Escribe aquí tu código y presiona "Run" para ejecutarlo.

# --- Ejemplo: variables y operaciones básicas ---
nombre = "Mundo"
print(f"¡Hola, {nombre}!")

# --- Ejemplo: lista y bucle ---
numeros = [1, 2, 3, 4, 5]
suma = sum(numeros)
print(f"La suma de {numeros} es: {suma}")

# --- Ejemplo: función ---
def saludar(persona):
    return f"Bienvenido, {persona}!"

print(saludar("Programador"))

# --- Escribe tu código a partir de aquí ---
